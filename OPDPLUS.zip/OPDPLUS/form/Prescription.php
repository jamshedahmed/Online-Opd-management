<?php
include('db.php');
ob_start();
session_start();
if(!isset($_SESSION['login_user']))
{
  echo"<script>alert('You Are not login')</script>";
  header("location:/OPDPLUS/form/login.php");
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Patient_App</title>

	<link rel="stylesheet" type="text/css" href="style.css">
	
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	
</head>
<body style="background:url('../form/images/h5.jpg');background-size:100% ";>
<?php
include 'header.php';
?>


<?php
$cn=$_GET['c'];
$sq="select * from appointment where CNIC='$cn'";

$result=mysqli_query($con,$sq);

while($row=mysqli_fetch_array($result))
{
    $id=$row['Appointment_ID'];

     $sql="select * from priscription where Appointment_id=$id";

    $sth = $con->query($sql);
    $res=mysqli_fetch_array($sth);

    echo '<img src="data:image/jpeg;base64,'.base64_encode( $res['Priscription_Image'] ).'"/>'; 




}

?>

    
</body>
</html>


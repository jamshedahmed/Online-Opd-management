<?php
include('db.php');
ob_start();
session_start();
if(!isset($_SESSION['login_user']))
{
  echo"<script>alert('You Are not login')</script>";
  header("location:/OPDPLUS/form/login.php");
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Patient_App</title>

  <link rel="stylesheet" type="text/css" href="style.css">
  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  
</head>
<body style="background:url('../form/images/h5.jpg');background-size:100% ";>
<?php
include 'header.php';
?>

    <div class="container">
    <div class="row">
        <div style="margin-left:60%;margin-top:10%" class="col-sm-6 col-md-4 col-md-offset-4">
            <h2 style="font-size: 32px;color: #fafafa" class="text-center">Please Enter Your CNIC Number</h2>
            <div style="background:url('../form/images/bg.png');border-radius:6px" class="account-wall">
                <form class="form-signin" method="post">
                <input type="text" class="form-control" name="Pcnic" placeholder="Patient CNIC" required autofocus><br>
                
                <button class="btn btn-lg btn-primary btn-block" name="sb" type="submit">
                    submit</button>
                
                </form>
            </div>
        </div>
    </div>
    </div>
   <?php
   if(isset($_POST['sb']))
   {
    $pc=$_POST['Pcnic'];
    $query="Select * from patient where Patient_CNIC='$pc'";

if ($result=mysqli_query($con,$query))
  {
  
  $rowcount=mysqli_num_rows($result);
  if($rowcount == 1)
  {
  
    header("Location:Track.php?PCNIC=$pc");

  }
  else{

    echo"<script>alert('CNIC is invalid')</script>";
  
  }
  
  }
}

    ?>
</body>
</html>


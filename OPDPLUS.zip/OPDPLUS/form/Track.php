<?php
include('db.php');
ob_start();
session_start();
if(!isset($_SESSION['login_user']))
{
  echo"<script>alert('You Are not login')</script>";
  header("location:/OPDPLUS/form/login.php");
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Patient_App</title>

  <link rel="stylesheet" type="text/css" href="style.css">
  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  
</head>
<body style="background:url('../form/images/h5.jpg');background-size:100% ";>
<?php
include 'header.php';
?>

    <div class="container">
    <div class="row">
    <?php
    $pc=$_GET['PCNIC'];
    $dt=date("d-m-Y");
    $query="select * from appointment where STR_TO_DATE(Date_of_Appoin,'%d-%m-%Y')>=STR_TO_DATE('$dt','%d-%m-%Y') AND CNIC=$pc order by STR_TO_DATE(Date_of_Appoin,'%d-%m-%Y') ASC"; 
    $run=mysqli_query($con,$query);
    
    while($row=mysqli_fetch_array($run))
    {
      $Pcn=$row['CNIC'];
      $DCNIC=$row['Doc_CNIC'];
      $dk=$row['DAY_KEY'];
      $date=$row['Date_of_Appoin'];

      $query2="select Name from doctor where Doc_CNIC='$DCNIC'";
    $run2=mysqli_query($con,$query2);
    while($row2=mysqli_fetch_array($run2))
    {
      $docName=$row2['Name'];
    }
    
    $query3="select * from day_timing where DAY_KEY='$dk'";
    $run3=mysqli_query($con,$query3);
    while($row3=mysqli_fetch_array($run3))
    {
      $day=$row3['Day'];
      $StartTime=$row3['Start_Time'];
      $EndTime=$row3['End_Time'];
    }

    if($date==$dt)
    {
   echo" 
        <a href='TrackNumber.php?Day=$dk&Dc=$DCNIC&DateT=$date'>";
      }
      echo"<div style='margin-left:0%;margin-top:5%;margin-bottom:-60px;width:100%' class='col-sm-6 col-md-4 col-md-offset-4'>
        <div style='background:url(../form/images/bg.png);border-radius:6px' class='account-wall'>
        <img style='float:left;width:130px;height:130px;border:1px solid lightgray' src='images/doc.jpg'>
        <div style='margin-left:140px'>
            <p><b>Name:Dr.$docName</b></p>
           <p><b>Date</b>: $date</p>
           <p><b>Day</b>: $day</p>
           <p><b>Start time</b>: $StartTime</p>
           <p><b>End time</b>: $EndTime</p>
        </div>
            

            </div>
    </div></a>
    ";
  
}
    ?>
    </div>
    </div>


</body>
</html>


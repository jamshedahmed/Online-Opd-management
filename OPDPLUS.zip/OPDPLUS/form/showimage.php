<?php
include 'db.php';
?>

<!DOCTYPE html>
<html>
<head>
	<title>Patient Prescription Images</title>
</head>
<body style="background:url('../form/images/bg.png')";>


<?php



$id=$_GET['id'];


$sql="select * from priscription where Appointment_id=$id";

$sth = $con->query($sql);
$result=mysqli_fetch_array($sth);

echo '<img style="margin-left: 35%" src="data:image/jpeg;base64,'.base64_encode( $result['Priscription_Image'] ).'"/>';

?>

</body>
</html>


<?php
include 'db.php';
?>


<!DOCTYPE html>
<html>
<head>
	<title>Patient Prescription Page</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

</head>
<body style="background:url('../form/images/h5.jpg');background-size:100% ">

<center><h1>DATE OF RECENT APPOINTMENTS</h1></center>


<?php

echo "<div style='margin-top:2%' class='container'>
    <div class='row'>
        <div class='col-sm-6 col-md-4 col-md-offset-4'>
            
            <div class='account-wall'>
                <img class='profile-img' src='ops.png'>";
//echo "string";
//$cnic=$_GET['pcn'];
$sql = "SELECT * FROM appointment WHERE cnic = " .$_GET['CNIC'] . "";
$sth = $con->query($sql);



while($result=mysqli_fetch_array($sth))
{

$dat= $result['Date_of_Appoin'];
$apid=$result['Appointment_ID'];

echo " <center> <a href='showimage.php?id=$apid'>".$dat."</a><br></center>";

echo "<br>";

//echo '<img src="data:image/jpeg;base64,'.base64_encode( $result['image'] ).'"/>';
//echo $cnic;

}
echo"</div>
            
        </div>
    </div>
</div>";
?>



</body>
</html>

<?php
include('db.php');
ob_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>LOGIN/SIGNUP</title>

	<link rel="stylesheet" type="text/css" href="style.css">
	
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	
</head>
<body style="background:url('images/h2.jpg');background-size:100% ";>
<?php
include '../form/header.php';
$docCNIC=$_GET['Dc'];
$dayk=$_GET['Day'];
$dateT=$_GET['DateT'];

 
$query="select * from tracking where Doc_CNIC='$docCNIC' AND DAY_KEY=$dayk";
$run=mysqli_query($con,$query);
while($row=mysqli_fetch_array($run))
{
  $PNOP=$row['Present_no_of_Patients'];
  $ATPP=$row['Avg_Time_per_patient'];
  $Msg=$row['Message'];
  $Status=$row['Status'];
}

$query2="select max(Appointment_No) As num from appointment where Doc_CNIC=$docCNIC AND DAY_KEY=$dayk AND Date_of_Appoin='$dateT'";
$run2=mysqli_query($con,$query2);
while($row2=mysqli_fetch_array($run2))
{
  $NO=$row2['num'];
  
}
echo"
    <div class='container'>
    <div class='row'>
        <div style='margin-left:0%;margin-top:15%;width: 100%' class='col-sm-6 col-md-4 col-md-offset-4'>
            
            <div style='background:url(images/bg.png);border-radius:6px' class='account-wall'>
                <b><p>Total Number of Patient: $NO</p></b>
                <b><p>Present_no_of_Patients: $PNOP</p>
                <p>Avg_Time_per_patient: $ATPP</p>
                <p>Message: $Msg</p>
                <p>Status: $Status</p></b>
                
        </div>
    </div>
</div>
</div>";
?>
   
</body>
</html>


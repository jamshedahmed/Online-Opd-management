<?php
include('db.php');
ob_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>LOGIN/SIGNUP</title>

	<link rel="stylesheet" type="text/css" href="style.css">
	
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	
</head>
<body style="background:url('images/h2.jpg');background-size:100% ";>
<?php
include '../header.php';
?>
<br><br><br><br><br>
    <div class="container">
    <div class="row">
        <div style="margin-left:60%" class="col-sm-6 col-md-4 col-md-offset-4">
            <h3 style="font-size: 32px;color: #fafafa" class="text-center">Sign_in to Continue to <b>OPDPlus</b></h3>
            <div style="background:url('images/bg.png');border-radius:6px" class="account-wall">
                <img class="profile-img" src="ops.png"
                    alt="">
                <form class="form-signin" method="post">
                <input type="text" class="form-control" name="C" placeholder="CNIC" required autofocus><br>
                <input type="text" class="form-control" name="ps" placeholder="Password" required><br>
                <button class="btn btn-lg btn-primary btn-block" name="sb" type="submit">
                    Sign in</button>
                <label class="checkbox pull-left">
                    <input type="checkbox" value="remember-me">
                    Remember me
                </label>
                <a href="#" class="pull-right need-help">Need help? </a><span class="clearfix"></span>
                </form>
            </div>
            <a style="color: #fafafa" href="reg.php" class="text-center new-account">Create an account </a>
            <br><br>
        </div>
    </div>
</div>
<?php
if(isset($_POST['sb'])){

    $CNIC=$_POST['C'];
    $password=$_POST['ps'];
   


$query="Select * from patient where Patient_CNIC='$CNIC' AND Password='$password'";

if ($result=mysqli_query($con,$query))
  {
  
  $rowcount=mysqli_num_rows($result);
  if($rowcount == 1)
  {
    session_start();
 $_SESSION['login_user']= $CNIC;
    header("location:http:../dashboard.php?CNIC=$CNIC");

  }
  else{

    echo"<script>alert('CNIC or Password is invalid')</script>";
  }
  }
}


?>
    
</body>
</html>


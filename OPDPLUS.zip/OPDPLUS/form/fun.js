
$(function (){
	$('#myModal').modal('show');

});
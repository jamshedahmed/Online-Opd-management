<?php
include('db.php');
ob_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Registration</title>

	<link rel="stylesheet" type="text/css" href="style.css">
	
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	
</head>
<body style="background:url('images/h6.jpg');background-size: 110% ";>
<?php
include '../header.php';
?>
<br><br><br><br><br>
    <div class="container">
    <div class="row">
        <div style="margin-left: 70px"  class="col-sm-6 col-md-4 col-md-offset-4">
            <h1 style="font-size: 40px;color: #fafafa" class="text-center"><b>Registration</b></h1>
            <div style="background:url('images/bg.png');border-radius:6px" class="account-wall">
            
                <form  class="form-signin" action="" method="post">
                <input type="text" class="form-control" name="C" placeholder="CNIC" required autofocus>
                <br>
                <input type="text" class="form-control" name="n" placeholder="Name" required autofocus><br>
                <input type="text" class="form-control" name="fn" placeholder="Father Name" required autofocus><br>
                <input type="text" class="form-control" name="contact" placeholder="Contact no" required autofocus><br>
                <input type="text" class="form-control" name="e" placeholder="Email" required autofocus><br>
                <input type="text" class="form-control" name="alg" placeholder="Allergies" autofocus><br>
                <input type="text" class="form-control" name="BG" placeholder="Blood Group" required autofocus><br>
                
                <textarea class="form-control" name="Ad" placeholder="Address" rows="4"
                                                        cols="60" required="required"></textarea>
                <input type="text" class="form-control" name="ps" placeholder="Chose_Password" required autofocus><br>
                <button class="btn btn-lg btn-primary btn-block" type="submit" name="sb">
                    Submit</button>
                
                
                </form>
            </div>
            
        </div>
    </div>
</div>

<?php
if(isset($_POST['sb'])){
    $cnic=$_POST['C'];
    $name=$_POST['n'];
    $fname=$_POST['fn'];
    $contact=$_POST['contact'];
    $email=$_POST['e'];
    $Allergies=$_POST['alg'];
    $bloodG=$_POST['BG'];
    $Address=$_POST['Ad'];
    $pass=$_POST['ps'];

    $insert="insert into patient(Patient_CNIC,Name,Fathers_Name,Contact_no,Email_Address,Allergies,Blood_Group,Address,Password) VALUES('$cnic','$name','$fname','$contact','$email','$Allergies','$bloodG','$Address','$pass')";
    $run=mysqli_query($con,$insert);
    if(!$run){
        echo"<script>alert('Try Agian connection problem')</script>";
    }
    else{
         echo"<script>alert('Registration Successfull')</script>";
    }

}


?>
    
</body>
</html>


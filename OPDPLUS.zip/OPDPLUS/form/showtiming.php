<?php
include('db.php');
session_start();
ob_start();
if(!isset($_SESSION['login_user']))
{
  echo"<script>alert('You Are not login')</script>";
  header("location:/OPDPLUS/form/login.php");
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>DOCTOR TIMINGS</title>

	<link rel="stylesheet" type="text/css" href="style.css">
	
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	
</head>
<body style="background:url('../form/images/h5.jpg');background-size:100% ";>
<?php 
include 'header.php';
?>
<br><br><br><br><br>
<?php

$dcnic=$_GET['DCNIC'];
$day=$_GET['DAY'];
$Appdate=$_GET['Appdate'];
$Pcnic=$_GET['Pcnic'];


$query1="select Start_Time from day_timing where Day='$day' AND DAY_KEY IN(select DAY_KEY from timing where Doc_CNIC=$dcnic)";
    $run1=mysqli_query($con,$query1);

    if(!$run1){
        echo"<script>alert('Try Agian something worng')</script>";
    }
    $queryS="select End_Time from day_timing where Day='$day' AND DAY_KEY IN(select DAY_KEY from timing where Doc_CNIC=$dcnic)";
    $run2=mysqli_query($con,$queryS);

    if(!$run2){
        echo"<script>alert('Try Agian something worng')</script>";
    }
    /*else{
         echo"<script>alert('ok1')</script>";
    }*/
echo "
    <div class='container'>
    <div class='row'>
        <div style='margin-left:' class='col-sm-6 col-md-4 col-md-offset-4'>
            <h1 style='font-size: 32px;color: #fafafa' class='text-center'>DOCTOR TIMINGS</h1>
            <div style='background:url(bg.png);border-radius:6px' class='account-wall'>

                <form class='form-signin' method='post'>";
echo "<select name='Stime' class='form-control'>";
while($row=mysqli_fetch_array($run1))
      {
        /*echo"<script>alert('ok12')</script>";*/
            
             $StartT=$row['Start_Time'];

                    echo "<option value='$StartT'>$StartT</option>";
      }
            echo"</select>";
  echo "<select name='Etime' class='form-control'>";
while($row=mysqli_fetch_array($run2))
      {
        /*echo"<script>alert('ok12')</script>";*/
            
             $EndT=$row['End_Time'];

                    echo "<option value='$EndT'>$EndT</option>";
      }
            echo"</select>";
    echo" <button class='btn btn-lg btn-primary btn-block' name='sb' type='submit'>
                    submit</button>
               </form>
            </div>
        </div>
    </div>
    ";
 if(isset($_POST['sb'])){
      $STimed=$_POST['Stime'];
      $ETimed=$_POST['Etime'];
      
      /*echo"<script>alert('$Timed')</script>";*/
    
    $bound=0;
    $num=0;
    global $DAY_KEY;
    //////////////////////////////////////////////////////////////////////////////////////////////
    $DAY_KEY=0;
    $q="select DAY_KEY from day_timing where Day='$day' AND Start_Time='$STimed' AND End_Time='$ETimed'";
      $rn=mysqli_query($con,$q);
    
             /*echo"<script>alert('boundas')</script>";*/

             while($row=mysqli_fetch_array($rn))
                {
                  $DAY_KEY=$row['DAY_KEY'];

                  /*echo"<script>alert($bound)</script>";*/

                }
                if($DAY_KEY!=0){
$query2="select max(Appointment_No) AS n  from appointment where Doc_CNIC=$dcnic AND Date_of_Appoin='$Appdate' AND DAY_KEY=(select DAY_KEY from day_timing where Day='$day' AND Start_Time='$STimed' AND End_Time='$ETimed')";
    
     if($run2=mysqli_query($con,$query2))
     {
        while($row=mysqli_fetch_array($run2))
        {
            $num=$row['n'];
            /*echo"<script>alert('num')</script>";
            echo"<script>alert($num)</script>";*/
        }
    }

    
    $query3="select Bound from timing where Doc_CNIC=$dcnic AND DAY_KEY IN(select DAY_KEY from day_timing where Day='$day' AND Start_Time='$STimed' AND End_Time='$ETimed')";
    
    if($run3=mysqli_query($con,$query3))
    {
             /*echo"<script>alert('boundas')</script>";*/

             while($row2=mysqli_fetch_array($run3))
                {
                  $bound=$row2['Bound'];

                  /*echo"<script>alert($bound)</script>";*/

                }
    }
    if($num+1>$bound)
    {

        echo "<script>alert('Appointment Full, Try for next day')</script>";
    }
    else{
$insert="Insert INTO appointment(Date_of_Appoin,Appointment_No,CNIC,Doc_CNIC,DAY_KEY) VALUES('$Appdate',$num+1,$Pcnic,$dcnic,$DAY_KEY)";
    $run4 = mysqli_query($con,$insert);
    
        
        if(!$run4)
        {
           echo"<script>alert('Not Allowed')</script>";
        }
    else{
        
         echo"<script>alert('Appointment Successfull')</script>";
         

    }


      }
    }
    else{
      echo"<script>alert('Wrong Timings')</script>";
    }
}

?>   


     
     
<!-- echo"<script>alert('Appointment Confirmed')</script>"; -->

</body>
</html>


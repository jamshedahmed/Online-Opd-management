<?php
$pc=$_GET['CNIC'];
?>
<!doctype html>
<html lang="en-gb" class="no-js">
<!--<![endif]-->
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<title>OPD PLUS</title>
<meta name="description" content="">
<meta name="author" content="WebThemez">

<link rel="stylesheet" href="css/bootstrap.min.css" />
<link rel="stylesheet" type="text/css" href="css/isotope.css" media="screen" />
<link rel="stylesheet" href="js/fancybox/jquery.fancybox.css" type="text/css" media="screen" />
<link href="css/animate.css" rel="stylesheet" media="screen">
<link href="flexslider/flexslider.css" rel="stylesheet" />
<link href="js/owl-carousel/owl.carousel.css" rel="stylesheet">
<link rel="stylesheet" href="css/styles.css" />
<!-- Font Awesome -->
<link href="font/css/font-awesome.min.css" rel="stylesheet">
</head>

<body>
<header class="header">
  <div class="container">
    <nav class="navbar navbar-inverse" role="navigation">
      <div class="navbar-header">
        <button type="button" id="nav-toggle" class="navbar-toggle" data-toggle="collapse" data-target="#main-nav"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
        <a href="#" class="navbar-brand scroll-top logo  animated bounceInLeft"><b style="font-size: 32px">OPD<i>PLUS</i></b></a> </div>
      <!--/.navbar-header-->
      <div id="main-nav" class="collapse navbar-collapse">
        <ul class="nav navbar-nav" id="mainNav">
          <li><a href="http:/OPDPLUS/dashboard.php?CNIC=<?php echo $pc ; ?>" class="scroll-link">Home</a></li>
          <li><a href="../dashboard.php#services" class="scroll-link">Services</a></li>
          <li><a href="../dashboard.php#aboutUs" class="scroll-link">About Us</a></li>
         <li><a href="http:/OPDPLUS/form/doctor_info.php?CNIC=<?php echo $pc ; ?>">Doctors</a></li>
         <li><a href="http:/OPDPLUS/form/PatientApp.php?CNIC=<?php echo $pc ; ?>">Appointment</a></li>
          <li><a href="http:/OPDPLUS/form/Pre.php?CNIC=<?php echo $pc ?>";" class="scroll-link">Prescription</a></li>
         <li><a href="http:/OPDPLUS/form/Tracking.php?CNIC=<?php echo $pc ; ?>" class="scroll-link">Tracking</a></li>
         <li><a href="http:/OPDPLUS/index.php">Log out</a></li>
         
          <li><a href="../dashboard.php?CNIC=<?php echo $pc ; ?>#contactUs" class="scroll-link">Contact Us</a></li>
          
        </ul>
      </div>
      <!--/.navbar-collapse--> 
    </nav>
    <!--/.navbar--> 
  </div>
  <!--/.container--> 
</header>
</body>
</html>
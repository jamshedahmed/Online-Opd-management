<?php
require "db.php";
$ContactNumber = $_POST["mPhoneNumber"];
$password = $_POST["mPassword"];
$query="Select * from patient where Contact_no='$ContactNumber' AND Password='$password'";
if ($result=mysqli_query($con,$query))
  {

  $rowcount=mysqli_num_rows($result);
  if($rowcount == 1)
  {
    echo"successful";

  }
  else{

    echo"unsuccessful";
  }
  }
mysqli_close($con);
?>
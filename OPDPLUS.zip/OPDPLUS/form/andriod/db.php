<?php
$sever="thecreatorstc.com";
$user="thecreat_OPD";
$Password="Fast12345";
$database="thecreat_plus";
$con=mysqli_connect($sever,$user,$Password,$database);
?>

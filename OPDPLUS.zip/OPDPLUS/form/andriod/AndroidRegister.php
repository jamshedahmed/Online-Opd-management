<?php
require "db.php";
$P_CNIC = $_POST["CNIC"];
$name = $_POST["Name"];
$F_Name = $_POST["FatherName"];
$C_no = $_POST["PhoneNumber"];
$Email_A = $_POST["EmailAddress"];
$allerg = $_POST["Allergies"];
$Blood_Gr = $_POST["BloodGroup"];
$address = $_POST["Address"];
$password = $_POST["Password"];

$mysql_qry = "INSERT into patient(Patient_CNIC,Name,Fathers_Name,Contact_no,Email_Address,Allergies,Blood_Group,Address,Password) values('$P_CNIC','$name','$F_Name','$C_no','$Email_A','$allerg','$Blood_Gr','$address','$password')";
if($con->query($mysql_qry) === TRUE)
{
    echo "INSERTED SUCCESSFULLY";
}
else
{
    echo"not SUCCESSFULL";

}
$con->close();
?>




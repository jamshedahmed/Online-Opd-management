<?php

// if($_SERVER['REQUEST_METHOD']=='GET'){



include('db.php');


$sql = "SELECT Doc_CNIC,Name,Specialization,Email_Adress,Fees_Per_Appoin FROM doctor";
$result = $con->query($sql);


$outp = '{ "doctors":[';
while($rs = $result->fetch_array(MYSQLI_ASSOC)) {
    if ($outp != '{ "doctors":[') {$outp .= ",";}
    $outp .= '{"Doc_CNIC":"'  . $rs["Doc_CNIC"] . '",';
    $outp .= '"Name":"'   . $rs["Name"]        . '",';
    $outp .= '"Specialization":"'   . $rs["Specialization"]        . '",';
    $outp .= '"Email_Adress":"'   . $rs["Email_Adress"]        . '",';
    $outp .= '"Fees_Per_Appoin":"'. $rs["Fees_Per_Appoin"]     . '"}';
}
$outp .="]}";

$con->close();

echo($outp);
?>
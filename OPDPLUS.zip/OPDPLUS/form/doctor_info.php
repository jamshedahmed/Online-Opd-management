<?php
session_start();
ob_start();
if(!isset($_SESSION['login_user']))
{
  echo"<script>alert('You Are not login')</script>";
  header("location:/OPDPLUS/form/login.php");
}
?>
<?php
include('db.php');
?>
<!DOCTYPE html>
<html>
<head>
	<title>Doctors Information</title>

	<link rel="stylesheet" type="text/css" href="style.css">
	
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	
</head>
<body style="background:url('images/h2.jpg');background-size:100% ";>
<?php
include 'header.php';
?>
<br><br><br><br><br>
    <div class="container">
    <div class="row">
        <div style="" >
         <?php
        $query="select * from doctor";
        $run=mysqli_query($con,$query);
        /*if(!$run)
        {
          echo"<script>alert('not')</script>";
        }
        else{
          echo"<script>alert('set')</script>";
        }*/
        while($row=mysqli_fetch_array($run))
        {
          $name=$row['Name'];
          $CNIC=$row['Doc_CNIC'];
          $Specialization=$row['Specialization'];
          $Email=$row['Email_Adress'];
          $Fees=$row['Fees_Per_Appoin'];
          $DOB=$row['Date_of_Birth'];

          echo"
          
            <div style='background:url(images/bg.png);width: 100%;margin: 1%; float: left; border-radius:6px' class='account-wall'>
            <img style='float:left;width:130px;height:130px;border:1px solid lightgray' src='images/doc.jpg'>
            <div style='margin-left:140px'>
                <h3 style='font-size: 32px;color: #000;margin-top: -20px'>Name:<b>Dr.$name</b></h3>
                <p style='font-size:16px;color: #000;line-height: 20px;border: 1px solid lightgray'><b>CNIC</b>: $CNIC</p>
                <p style='font-size:16px;color: #000;line-height: 20px;border: 1px solid lightgray'> <b>Email</b>: $Email</p>
                <p style='font-size:16px;color: #000;line-height: 20px;border: 1px solid lightgray'><b>Specialization</b>: $Specialization</p>
                <p style='font-size:16px;color: #000;line-height: 20px;border: 1px solid lightgray'><b>Fees</b>:Rs.$Fees/-</p>
                <p style='font-size:16px;color: #000;line-height: 20px;border: 1px solid lightgray'><b>Date of birth</b>: $DOB</p></div>";
                $query2="select * from day_timing where DAY_KEY IN(select DAY_KEY from timing where Doc_CNIC=$CNIC)";
                $run2=mysqli_query($con,$query2);

                while($row2=mysqli_fetch_array($run2))
               {
                $day=$row2['Day'];
                $start_time=$row2['Start_Time'];
                $end_time=$row2['End_Time'];
                echo"
                <p style='font-size:10px;color: #000;border: 1px solid lightgray'><b>$day</b>: $start_time to $end_time</p>";
              }
            echo"</div>";
        }
        ?>
            

              
        </div>
       
    </div>
</div>
<?php
if(isset($_POST['sb'])){

    $CNIC=$_POST['C'];
    $password=$_POST['ps'];
   


$query="Select * from patient where Patient_CNIC='$CNIC' AND Password='$password'";

if ($result=mysqli_query($con,$query))
  {
  
  $rowcount=mysqli_num_rows($result);
  if($rowcount == 1)
  {
    header("location:/OPDPLUS/dashboard.php?CNIC=$CNIC");

  }
  else{

    echo"<script>alert('CNIC or Password is invalid')</script>";
  }
  }
}


?>
    
</body>
</html>


<?php
 include('db.php');
?>
<!DOCTYPE html>
<html>
<head>
<title>    Processing
</title>
 <meta charset="UTF-8">
</head>
<body>
    
<?php
   $variable=explode(',', $_GET['vars']);
       $ap=$variable[0];
       $cnic=$variable[1];
    echo $cnic;
    	$op = array();
    	
    	
    	$op = $_POST['operation'];
        echo 'count($op)';
    	
    	for($counter = 0; $counter < count($op); $counter++)
    	{
             $a = $op[$counter];
             echo $a;
             echo"<script>alert($a'zaid')</script>";
             $que="insert into operation_performed(Appointment_ID,Operation_ID) values('$ap','$a')"; 
             $run=mysqli_query($con,$que);

             if($run)
             {
                echo"<script>alert('Information submited suucessfully')</script>";
             }
            
               
    	}
          echo"<script>alert($a'zaid')</script>";
          header("location:billform.php?many=$ap,$cnic");


?>



</body>
</html>
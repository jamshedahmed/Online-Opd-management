<?php
include('db.php');
?>

<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>Simple HTML/CSS Contact Form</title>
  
  
       <link rel="stylesheet" href="style2.css" media="all" />
      <link rel="stylesheet" type="/text/css" href="/css/style.css">

  
</head>
<?php
 $variable=explode(',', $_GET['many']);
       $app=$variable[0];
       $cnic=$variable[1];

      //echo 'zaid';
       $op=array();
      $op = $_POST['operation'];
        //echo sizeof($op);
      
      for($counter = 0; $counter < sizeof($op); $counter++)
      {
             $a = $op[$counter];
           //  echo $a;
             //echo"<script>alert($a'zaid')</script>";
             $que="insert into operation_performed(Appointment_ID,Operation_ID) values('$app','$a')"; 
             $run=mysqli_query($con,$que);

             /*if($run)
             {
                echo"<script>alert('Information submited suucessfully')</script>";
             }
            */
               
      }












$query = "select Fees_Per_Appoin,Name from doctor where Doc_CNIC = (select DOC_CNIC from appointment where Appointment_ID='$app') ";
$run = mysqli_query($con,$query);

$row= mysqli_fetch_array($run);
$fee=$row['Fees_Per_Appoin'];
$name=$row['Name'];

$qua="select * from patient where Patient_CNIC=(select CNIC from appointment where Appointment_ID='$app')";
$runa=mysqli_query($con,$qua);

$rowa= mysqli_fetch_array($runa);
$patname=$rowa['Name'];


$qu="select sum(Amount) from operation_name where Operation_ID IN (select Operation_ID from operation_performed where Appointment_ID='$app') group by Operation_ID";
$run2 = mysqli_query($con,$qu);
$total=0;
while($row2= mysqli_fetch_array($run2)){
$total = $total+$row2['sum(Amount)'];
}
$t=$total+$fee;
$d=date("d/m/Y");
$sql="insert into bill(Date_of_Bill,Paid,Staff_CNIC,Appointment_ID) values ('$d','$t','$cnic','$app')";
$r=mysqli_query($con,$sql);
if($r)
             {
                echo"<script>alert('Information submited suucessfully')</script>";
             }
             else
                  echo"<script>alert('Something wrong Try again')</script>";
//echo $total;
?>
<img class="profile-img" src="ops.png" align="center" 
                    alt="">


   <form method="GET" id="my_form"></form>
    
   <h1>YOUR BILL</h1>

    <main>
      <table>
        <thead>
          <tr>
            <th class="service">TITLE</th>
            <th class="desc">INFORMATION</th>
            
          </tr>
        </thead>
        <tbody>
          <tr>
            <td class="service">DOCTOR NAME</td>

            
            <td class="desc"><?php echo $name; ?></td>
           
          </tr>
          <tr>
            <td class="service">PATIENT NAME</td>
            <td class="desc"><?php echo $patname; ?></td>
            
           
          </tr>
          <tr>
            <td class="service">DOCTOR FEE</td>
            <td class="desc"><?php echo $fee; ?></td>
            
            
          </tr>
            
          <tr>
            <td class="service">OPERATION FEE</td>
            <td class="desc"><?php echo $total;   ?></td>
           
            
          </tr>

          <tr>
            
            <td class="service">TOTAL AMOUNT</td>
            <td class="desc"><?php echo $t;?></td>

          </tr>




        </tbody>
      </table>


<?php

if (isset($_POST['sub'])) {
  
  # code...
}
?>
  
  
</body>
</html>

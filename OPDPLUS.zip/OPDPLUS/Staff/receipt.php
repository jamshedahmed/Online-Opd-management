<?php
include('db.php');
?>


<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>Simple HTML/CSS Contact Form</title>
  <link rel="stylesheet" type="text/css" href="style.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body style="background-image: url('../form/images/bg.png')">
<?php
include 'header.php';
?>


<?php
$s=$_GET['cn'];
?>
<div  class="container">  
  <form style="margin-top: 15%;width: 30%"  id="contact" action="" method="post">
    <h4><b>Patient Bill </b>Contact us for any Issue</h4>
  
      <input placeholder="Appointment Id" class="form-control" type="text" tabindex="1" name="Dname" required autofocus><br>
     <input class="form-control" placeholder="Total No Of operation" type="text" tabindex="1" name="NoPat" required autofocus><br>
<button  class="btn btn-lg btn-primary btn-block" type="submit" name="sub" >Submit</button>
  </form>
</div>




<?php

  if(isset($_POST['sub']))
  {
     $no = $_POST['NoPat'];
     $ap= $_POST['Dname'];

     echo "<form method = 'POST' action = 'billform.php?many=$ap,$s'>";
      for($counter = 0; $counter < $no; $counter++)
      {
        echo "<input type = 'text' name = 'operation[]' class = 'class_name'/><br/>";
      }
        echo "<input type = 'submit' value = 'SEND'/>";
        echo "</form>";
  }

?>



  
</body>
</html>

	<!DOCTYPE html>
<html>
<head>
	<title>
		Admin Panel
	</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body style="background-image: url('../form/images/admin.jpg');background-size: 100%";>
<?php
$nic=$_GET['cn']

include 'header.php';
?>



</style>
</body>
</html>
<?php
$host="localhost";
$user="Ahmed";
$pass="Fast12345";
$db="plus";
?>
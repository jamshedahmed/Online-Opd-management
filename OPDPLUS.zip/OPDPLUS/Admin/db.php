<?php
$sever="localhost";
$user="Ahmed";
$Password="Fast12345";
$database="plus";
$con=mysqli_connect($sever,$user,$Password,$database);
?>

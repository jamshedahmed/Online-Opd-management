<?php
include('db.php');
?>

<!DOCTYPE html>
<html>
<head>
	<title>Doctor</title>

	<link rel="stylesheet" type="text/css" href="style.css">
	
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	
</head>
<body style="background:url('../form/images/h4.jpg');background-size: 125%";>
<?php 
include 'header.php';
?>
<br><br><br><br><br>
    <div class="container">
    <div class="row">
        <div style="margin-left:60%" class="col-sm-6 col-md-4 col-md-offset-4">
            <h1 style="font-size: 40px;color: #fafafa" class="text-center"><b>Staff Info</b></h1>
            <div style="background:url('../form/images/bg.png');border-radius:6px" class="account-wall">
                <form class="form-signin" method="post">
                <input type="text" class="form-control" name="C" placeholder="CNIC" required autofocus><br>
                <input type="text" class="form-control" name="n" placeholder="Name" required autofocus><br>
                <input type="text" class="form-control" name="fn" placeholder="Father name" required autofocus><br>
                <input type="text" class="form-control" name="dob" placeholder="Date-Of-Birth" required autofocus><br>
                <input type="text" class="form-control" name="em" placeholder="Email Adress" required autofocus><br>
                <input type="text" class="form-control" name="ad" placeholder="Address" required autofocus><br>
                <input type="text" class="form-control" name="r" placeholder="Role" required autofocus><br>
                <input type="text" class="form-control" name="dst" placeholder="Duty-Start-Time" required autofocus><br>
                <input type="text" class="form-control" name="dlt" placeholder="Duty-Last-Time" required autofocus><br>
                <input type="text" class="form-control" name="sal" placeholder="Salary" required autofocus><br>
                <input type="text" class="form-control" name="ps" placeholder="Assign-password" required><br>

                <button class="btn btn-lg btn-primary btn-block" name="sb" type="submit">
                    submit</button>
                
                </form>
            </div>
        </div>
    </div>
<?php
if(isset($_POST['sb'])){
    $cnic=$_POST['C'];
    $name=$_POST['n'];
    $fname=$_POST['fn'];
    $birth=$_POST['dob'];
    $email=$_POST['em'];
    $addr=$_POST['ad'];
    $role=$_POST['r'];
    $start=$_POST['dst'];
    $last=$_POST['dlt'];
    $salary=$_POST['sal'];
    $pass=$_POST['ps'];

    $insert="insert into staff(Staff_CNIC,Name,Fathers_Name,Email_Address,Address,Role,Duty_Start_Time,Duty_End_Time,Staff_Salary,Password,Date_Of_Birth) VALUES('$cnic','$name','$fname','$email','$addr','$role','$start','$last','$salary','$pass','$birth')";
    $run=mysqli_query($con,$insert);
    if(!$run){
        echo"<script>alert('Something wrong Try again')</script>";
    }
    else{
        
         echo"<script>alert('Information submited suucessfully')</script>";
    }

}


?>
    
</body>
</html>


<?php
session_start();
ob_start();
if(!isset($_SESSION['login_Admin']))
{
  echo"<script>alert('You Are not login')</script>";
  header("location:/OPDPLUS/Admin/index.php");
}
?>
<?php
include('db.php');
?>
<!DOCTYPE html>
<html>
<head>
	<title>Timings</title>

	<link rel="stylesheet" type="text/css" href="style.css">
	
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	
</head>
<body style="background:url('../form/images/h6.jpg');background-size: 110% ";>
<?php
include 'header.php';
?>
<br><br><br><br><br>
    <div class="container">
    <div class="row">
        <div style="margin-left: 70px"  class="col-sm-6 col-md-4 col-md-offset-4">
            <h1 style="font-size: 40px;color: #fafafa" class="text-center"><b>Enter Doctor Timings</b></h1>
            <div style="background:url('../form/images/bg.png');border-radius:6px" class="account-wall">
            
                <form  class="form-signin" action="" method="post">
                <input type="text" class="form-control" name="Dcnic" placeholder="Doctor Cnic" required autofocus>
                <br>
                
                
                <button class="btn btn-lg btn-primary btn-block" type="submit" name="sb">
                    Submit</button>
                
                
                </form>
            </div>
            
        </div>
    </div>
</div>

<?php
if(isset($_POST['sb'])){
    $dcnic=$_POST['Dcnic'];
  
    
    $query="select DAY_KEY from timing where Doc_CNIC=$dcnic";
    $run=mysqli_query($con,$query);
   
    

            while($row=mysqli_fetch_array($run))
            {
               $dayK=$row['DAY_KEY'];
               
               $query2="select * from day_timing where DAY_KEY=$dayK";
               $run2=mysqli_query($con,$query2);
               while($row2=mysqli_fetch_array($run2))
               {
                $day=$row2['Day'];
                $startT=$row2['Start_Time'];
                $EndT=$row2['End_Time'];
                echo"
                <a href='IntertimeUpdate.php?day=$day&st=$startT&et=$EndT&dc=$dcnic'><div style='margin-left:140px'>
                <p style='font-size:18px;width:50%;border:1px solid #000;border-radius:10px;color: #000;margin-top: -20px'>Name:<b>Day: $day  / Start_time: $startT  /End_Time: $EndT </b></p>
                </div></a>
                ";


               }
                


            }
        }
           

?>
    
</body>
</html>


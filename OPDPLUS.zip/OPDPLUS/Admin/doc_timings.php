<?php
session_start();
ob_start();
if(!isset($_SESSION['login_Admin']))
{
  echo"<script>alert('You Are not login')</script>";
  header("location:/OPDPLUS/Admin/index.php");
}
?>
<?php
include('db.php');
?>
<!DOCTYPE html>
<html>
<head>
	<title>Doctor Timings</title>

	<link rel="stylesheet" type="text/css" href="style.css">
	
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	
</head>
<body style="background:url('../form/images/h6.jpg');background-size: 110% ";>
<?php
include 'header.php';
?>
<br><br><br><br><br>
    <div class="container">
    <div class="row">
        <div style="margin-left: 70px"  class="col-sm-6 col-md-4 col-md-offset-4">
            <h1 style="font-size: 40px;color: #fafafa" class="text-center"><b>Enter Doctor Timings</b></h1>
            <div style="background:url('../form/images/bg.png');border-radius:6px" class="account-wall">
            
                <form  class="form-signin" action="" method="post">
                <input type="text" class="form-control" name="Dcnic" placeholder="Doctor Cnic" required autofocus>
                <br>
                <input type="text" class="form-control" name="day" placeholder="Day 'Monday'" required autofocus>
                <br>
                <input type="text" class="form-control" name="st" placeholder="Start Time 'HH:MM:PM/AM'" required autofocus><br>
                <input type="text" class="form-control" name="et" placeholder="End Time 'HH:MM:PM/AM'" required autofocus><br>
                <input type="number" class="form-control" name="lmt" placeholder="Patients Limit" required autofocus><br>
                
                <button class="btn btn-lg btn-primary btn-block" type="submit" name="sb">
                    Submit</button>
                
                
                </form>
            </div>
            
        </div>
    </div>
</div>

<?php
if(isset($_POST['sb'])){
    $dcnic=$_POST['Dcnic'];
    $day=$_POST['day'];
    $startT=$_POST['st'];
    $endT=$_POST['et'];
    $limit=$_POST['lmt'];
    
    $query="select DAY_KEY from day_timing where Day='$day' AND Start_time='$startT' AND End_Time='$endT'";
    $run=mysqli_query($con,$query);
   $rowcount=mysqli_num_rows($run);
    if($rowcount==1)
    {
            while($row=mysqli_fetch_array($run))
            {
                $key=$row['DAY_KEY'];
                //echo"<script>alert($key)</script>";
            }
            $insert="Insert into timing(Doc_CNIC,DAY_KEY,Bound) VALUES($dcnic,$key,$limit)";
            $run2=mysqli_query($con,$insert);
            if(!$run2)
            {
                 echo"<script>alert('Try Agian1')</script>";
            }
            else
            {
                echo"<script>alert('Timing Successfully Recorder')</script>";
            }
        }
        else
        {
            $query2="select max(DAY_KEY) As k from day_timing";
            if($run=mysqli_query($con,$query2))
            {
               while($row=mysqli_fetch_array($run))
               {
                $key=$row['k'];
                // echo"<script>alert($key)</script>";

                }
                $insert1="insert into day_timing(DAY_KEY,Day,Start_Time,End_Time) VALUES($key+1,'$day','$startT','$endT')";
                $run2=mysqli_query($con,$insert1);
                if(!$run2)
                {
                 echo"<script>alert('Try Agian')</script>";
                }
                 /* else
                 {
                     echo"<script>alert('Timing Successfully Recorder')</script>";
                }*/

                $insert2="insert into timing(Doc_CNIC,DAY_KEY,Bound) VALUES($dcnic,$key+1,$limit)";

                 $run3=mysqli_query($con,$insert2);
                if(!$run3)
                {
                     echo"<script>alert('Try Agian3')</script>";
                }
                else
                {
                    echo"<script>alert('Timing Successfully Recorder')</script>";
                }
            }
        /*else{
            $insert1="insert into day_timing(DAY_KEY,Day,Start_Time,End_Time) VALUES(1,'$day','$startT','$endT')";
             $run2=mysqli_query($con,$insert1);
            if(!$run2)
            {
                 echo"<script>alert('Try Agian connection problem')</script>";
            }
            else
            {
                echo"<script>alert('OK!')</script>";
            }
        }*/


            
        }

   }


?>
    
</body>
</html>


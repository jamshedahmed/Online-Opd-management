<?php
include('db.php');
ob_start();
session_start();
if(!isset($_SESSION['login_Admin']))
{
  echo"<script>alert('You Are not login')</script>";
  header("location:/OPDPLUS/Admin/index.php");
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Patient_App</title>

	<link rel="stylesheet" type="text/css" href="style.css">
	
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	
</head>
<body style="background:url('../form/images/h5.jpg');background-size:100% ";>
<header class="header">
  <div class="container">
    <nav class="navbar navbar-inverse" role="navigation">
      <div class="navbar-header">
        <button type="button" id="nav-toggle" class="navbar-toggle" data-toggle="collapse" data-target="#main-nav"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
        <a href="#" class="navbar-brand scroll-top logo  animated bounceInLeft"><b style="font-size: 32px">OPD<i>PLUS</i></b></a> </div>
      <!--/.navbar-header-->
      <div id="main-nav" class="collapse navbar-collapse">
        <ul class="nav navbar-nav" id="mainNav">
          <li class="" id="firstLink"><a href="admin.php" class="scroll-link">Home</a></li>
          <li><a href="http:/OPDPLUS/Admin/PatientApp.php" class="scroll-link">Patient Appointment</a></li>
          <li><a href="http:/OPDPLUS/Admin/reg.php" class="scroll-link">Patient Registration</a></li>
         <li><a href="http:/OPDPLUS/Admin/doctor.php" class="scroll-link">Doctors</a></li>
         <li><a href="http:/OPDPLUS/Admin/doc_timings.php" class="scroll-link">Doctors Timings</a></li>
          <li><a href="http:/OPDPLUS/Admin/index.php" class="scroll-link">Log out</a></li>
         
          
          
        </ul>
      </div>
      <!--/.navbar-collapse--> 
    </nav>
    <!--/.navbar--> 
  </div>
  <!--/.container--> 
</header>
<div class="container">
    <div class="row">
        <div style="margin-left:60%;margin-top:10%" class="col-sm-6 col-md-4 col-md-offset-4">
            <h1 style="font-size: 32px;color: #fafafa" class="text-center">Patient Appointment</h1>
            <div style="background:url('../form/images/bg.png');border-radius:6px" class="account-wall">
                <form class="form-signin" method="post">
                <input type="text" class="form-control" name="Pcnic" placeholder="Patient CNIC" required autofocus><br>
                <input type="text" class="form-control" name="DCNIC" placeholder="Doctor DCIN" required autofocus><br>
                <select name="day" class="form-control">
                    <option name="Monday">Monday</option>
                    <option name="Tuesday">Tuesday</option>
                    <option name="Wednesday">Wednesday</option>
                    <option name="Thursday">Thursday</option>
                    <option name="Friday">Friday</option>
                    <option name="Saturday">Saturday</option>
                    <option name="Sunday">Sunday</option>
                </select>
                <input type="text" class="form-control" name="doa" placeholder="Date (yyyy-mm-dd)" required autofocus><br>
                <button class="btn btn-lg btn-primary btn-block" name="sb" type="submit">
                    submit</button>
                
                </form>
            </div>
        </div>
    </div>
    </div>
<?php
$bound=0;
$num=0;
if(isset($_POST['sb']))
{
    
    
    $check=false;
    $pc=$_POST['Pcnic'];
    $dc=$_POST['DCNIC'];
    $day=$_POST['day'];
    $dt=$_POST['doa'];
    $query="Select Day from day_timing where DAY_KEY IN(select DAY_KEY from timing where Doc_CNIC=$dc)";
     if($run=mysqli_query($con,$query))
     {
         while($row=mysqli_fetch_array($run))
         {
            $d=$row['Day'];
            if($d==$day){
               $check=true;
               break;
            }
         }
     }
     if($check){
        header("location:showtiming.php?DCNIC=$dc&DAY=$day&Appdate=$dt&Pcnic=$pc");
     }
     else{

        echo"<script>alert('Wrong Day')</script>";
     }
     
}
?>   
    
</body>
</html>
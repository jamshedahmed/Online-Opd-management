<?php
include('db.php');
ob_start();
session_start();
if(!isset($_SESSION['login_Doctor']))
{
  echo"<script>alert('You Are not login')</script>";
  header("location:/OPDPLUS/Doctor/index.php");
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>LOGIN</title>

	<link rel="stylesheet" type="text/css" href="style.css">
	
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	
</head>
<body style="background:url('bg.png')>
<?php
include 'doc.php';

?>
<br><br><br><br>


    <div class="container">
    <div class="row">
        <div class="col-sm-6 col-md-4 col-md-offset-4">
            <h1 class="text-center login-title">Enter Timings</h1>
            <div class="account-wall">
                <img class="profile-img" src="ops.png"
                    alt="">
                <form class="form-signin" method="post">
                
                <input type="text" class="form-control" name="day" placeholder="DAY" required autofocus><br>
                <input type="text" class="form-control" name="Stime" placeholder="Start_Time (HH:MM:PM/AM)" required><br>
                <input type="text" class="form-control" name="Etime" placeholder="End_Time (HH:MM:PM/AM)" required><br>
                <button class="btn btn-lg btn-primary btn-block" name="sb" type="submit">
                    Submit</button>
               
                </form>
            </div>
            
        </div>
    </div>
</div>
<?php
$dcnic=$_GET['DCNIC'];
if(isset($_POST['sb'])){
    $date=date("d-m-Y");
    $day=$_POST['day'];
    $Stime=$_POST['Stime'];
    $Etime=$_POST['Etime'];
    echo"<script>alert('$date')</script>";
    
$query1="select DAY_KEY from day_timing where Day='$day' AND Start_Time='$Stime' AND End_Time='$Etime'";
 if($run1=mysqli_query($con,$query1))
 {
while($row=mysqli_fetch_array($run1))
 {
    $dayK=$row['DAY_KEY'];
    
 }

 $query="select max(Appointment_No) AS no from appointment where Date_of_Appoin='$date' AND Doc_CNIC=$dcnic AND DAY_KEY=(select DAY_KEY from day_timing where Day='$day' AND Start_Time='$Stime' AND End_Time='$Etime')";
 $run=mysqli_query($con,$query);
while ($row=mysqli_fetch_array($run))
{
  $Total_pateint=$row['no'];
    
}
if($Total_pateint==0)
{
    echo"<script>alert('No Appoitment')</script>";
}
else{
 header("location:Traking.php?Total_Pateint=$Total_pateint&DCNIC=$dcnic&Date=$date&DAYK=$dayK");
}

}
else{
    echo"<script>alert('Wrong data')</script>";
}
}
?>
    
</body>
</html>

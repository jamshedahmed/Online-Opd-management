<?php
include ('db.php');
session_start();
ob_start();
if(!isset($_SESSION['login_Doctor']))
{
  echo"<script>alert('You Are not login')</script>";
  header("location:/OPDPLUS/Doctor/index.php");
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>
        Admin Panel
    </title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body style="background-image: url('../form/images/bg.png')";>
<header class="header">
  <div class="container">
    <nav class="navbar navbar-inverse" role="navigation">
      <div class="navbar-header">
        <button type="button" id="nav-toggle" class="navbar-toggle" data-toggle="collapse" data-target="#main-nav"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
        <a href="#" class="navbar-brand scroll-top logo  animated bounceInLeft"><b style="font-size: 32px">OPD<i>PLUS</i></b></a> </div>
      <!--/.navbar-header-->
      <div id="main-nav" class="collapse navbar-collapse">
        <ul class="nav navbar-nav" id="mainNav">
        <?php
        $DC=$_GET['DCNIC'];
          echo"<li><a href='doc.php?DCNIC=$DC' class='scroll-link'>Home</a></li>";
          ?>
          <li><a href="http:/OPDPLUS/Doctor/index.php" class="scroll-link">Log out</a></li>
        </ul>
      </div>
      <!--/.navbar-collapse--> 
    </nav>
    <!--/.navbar--> 
  </div>
  <!--/.container--> 
</header>

<?php
global $Countr;
$TP=$_GET['Total_Pateint'];
$DC=$_GET['DCNIC'];
$DAY_KEY=$_GET['DAYK'];
$DateT=$_GET['Date'];



$avge=10;
/*echo"<script>alert($DC)</script>";
echo"<script>alert('$time')</script>";
echo"<script>alert('$date')</script>";*/
echo"
<div style='margin-top:5%;margin-left:35%' class='container'>
    <div class='row'>
        <div style='margin-left:0%' class='col-sm-6 col-md-4 col-md-offset-4'>
            <h3 style='font-size: 32px;color: #fafafa' class='text-center'>Traking<b>OPDPlus</b></h3>
            <div style='background:url(../form/images/bgh.png);border-radius:6px' class='account-wall'>
                <img class='profile-img' src='ops.png'>
                <h3>Total number of patient is $TP</h3>
                <form method='post'>
                <button class='btn btn-lg btn-primary btn-block' name='sb' type='submit'>
                    Next Patient</button>
                </form>
            </div>
        </div>
    </div>
</div>";
if(isset($_POST['sb']))
{

  $query2="select Present_no_of_Patients from tracking where Doc_CNIC=$DC AND DAY_KEY=$DAY_KEY";
if($run2=mysqli_query($con,$query2))
{
 while($row=mysqli_fetch_array($run2))
 {
    $Countr=$row['Present_no_of_Patients'];
    
 }
 
}
else{
  $Countr=0;
  
}
  if($Countr==0)
  {
  $Countr++;
  $query="insert into tracking(Doc_CNIC,DAY_KEY,Present_no_of_Patients,Avg_Time_per_patient,Message,Status,Date_of_track) VALUES($DC,$DAY_KEY,$Countr,$avge,'NO','1','$DateT')";

$run=mysqli_query($con,$query);
  /*if(!$run)
  {
    echo"<script>alert('Khatraa')</script>";
  }
  else{

    echo"<script>alert('set hai')</script>";
  }*/
}
else
{
  if($Countr+1>$TP){
    echo"<script>alert('No Other Patient')</script>";
  }
  else{
  $query3="update tracking SET Present_no_of_Patients=$Countr+1 where  Doc_CNIC=$DC AND DAY_KEY=$DAY_KEY";
  $run3=mysqli_query($con,$query3);
  /*if(!$run3)
  {
    echo"<script>alert('Khatraa1')</script>";
  }
  else{

    echo"<script>alert('set hai..11')</script>";
  }*/
}
}
}


?>



</style>
</body>
</html>
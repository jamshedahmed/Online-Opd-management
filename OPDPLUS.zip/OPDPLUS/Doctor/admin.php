<!DOCTYPE html>
<html>
<head>
	<title>
		Admin Panel
	</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body style="background-image: url('../form/images/admin.jpg');background-size: 100%";>
<?php
include 'header.php';

$c=$_GET['cn'];

?>
<header class="header">
  <div class="container">
    <nav class="navbar navbar-inverse" role="navigation">
      <div class="navbar-header">
        <button type="button" id="nav-toggle" class="navbar-toggle" data-toggle="collapse" data-target="#main-nav"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
        <a href="#" class="navbar-brand scroll-top logo  animated bounceInLeft"><b style="font-size: 32px">OPD<i>PLUS</i></b></a> </div>
      <!--/.navbar-header-->
      <div id="main-nav" class="collapse navbar-collapse">
        <ul class="nav navbar-nav" id="mainNav">
          <li class="" id="firstLink"><a href="../index.php" class="scroll-link">Home</a></li>
         
<li><a href="My_Patients.php?cn=<?php echo $c; ?>" class="scroll-link"> My Patients </a>
         <li><a href="index.php" class="scroll-link">Log Out</a></li>



         
          
          
        </ul>
      </div>
      <!--/.navbar-collapse--> 
    </nav>
    <!--/.navbar--> 
  </div>
  <!--/.container--> 
</header>






</style>
</body>
</html>
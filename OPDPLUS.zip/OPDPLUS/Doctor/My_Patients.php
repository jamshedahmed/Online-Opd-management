<?php
include('db.php');

?>

<!DOCTYPE html>
<html>
<head>
	<title>My Patients</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	
</head>
<body style="background-image: url('../form/images/admin.jpg');background-size: 100%";>
<header class="header">
  <div class="container">
    <nav class="navbar navbar-inverse" role="navigation">
      <div class="navbar-header">
        <button type="button" id="nav-toggle" class="navbar-toggle" data-toggle="collapse" data-target="#main-nav"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
        <a href="#" class="navbar-brand scroll-top logo  animated bounceInLeft"><b style="font-size: 32px">OPD<i>PLUS</i></b></a> </div>
      <!--/.navbar-header-->
      <div id="main-nav" class="collapse navbar-collapse">
        <ul class="nav navbar-nav" id="mainNav">
       <?php
       $DCNIC=$_GET['cn'];
       echo"
          <li><a href='http:/OPDPLUS/Doctor/Traking_time.php?DCNIC=$DCNIC' class='scroll-link'>Traking</a></li>";
          ?>
        <li><a href="My_Patients.php?cn=<?php echo $DCNIC; ?>" class="scroll-link"> My Patients </a>
          <li><a href="http:/OPDPLUS/Doctor/index.php" class="scroll-link">Log out</a></li>
         
          
          
        </ul>
      </div>
      <!--/.navbar-collapse--> 
    </nav>
    <!--/.navbar--> 
  </div>
  <!--/.container--> 
</header>

<?php
$cnic=$_GET['cn'];

$query="select distinct(cnic)  from appointment";
$result=mysqli_query($con,$query);

echo "<table>"; // start a table tag in the HTML

if ($result)
{
	echo"
<div style='margin-top:5%' class='container'>
    <div class='row'>
        <div class='col-sm-6 col-md-4 col-md-offset-4'>
            <h1 class='text-center'>Patients List</h1>
            <div class='account-wall'>
                <img class='profile-img' src='ops.png'>";
                
            
while($row = mysqli_fetch_array($result)){   //Creates a loop to loop through results
//echo "<tr><td>" .$row['cnic'] ;  //$row['index'] the index here is a field name
//echo "<a href='$row['cnic']'>Link</a>";
	$r=$row['cnic'];
        $q="select * from patient where Patient_CNIC='$r'";
        $res=mysqli_query($con,$q);
        $row1=mysqli_fetch_array($res);
        $na=$row1['Name'];

	echo "
	<center><b> <a href='pre.php?pcn=$r'>".$na."</a></b><br><br><br></center>";
}
echo"</div>
            
        </div>
    </div>
</div>";
}
else
{
	echo"<script>alert('CNIC or Password is invalid')</script>";
}


?>

</body>
</html>






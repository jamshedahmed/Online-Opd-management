<?php
$host="localhost";
$user="Ahmed";
$pass="Fast1234";
$db="plus";
?>
<?php

$db = mysqli_connect("localhost","Ahmed","Fast1234","plus"); 
$sql = "SELECT * FROM test_image WHERE id = " .$_GET['id'] . "";
$sth = $db->query($sql);
$result=mysqli_fetch_array($sth);
echo '<img src="data:image/jpeg;base64,'.base64_encode( $result['image'] ).'"/>';

?>
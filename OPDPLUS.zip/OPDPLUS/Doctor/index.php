<?php
include('db.php');
ob_start();
session_start();
if(isset($_SESSION["login_Doctor"])){
    session_destroy();
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>LOGIN</title>

	<link rel="stylesheet" type="text/css" href="style.css">
	
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	
</head>
<body style="background:url('bg.png')>

    <div class="container">
    <div class="row">
        <div class="col-sm-6 col-md-4 col-md-offset-4">
            <h1 class="text-center login-title">Sign in to continue to OPDPlus</h1>
            <div class="account-wall">
                <img class="profile-img" src="ops.png"
                    alt="">
                <form class="form-signin" method="post">
                <input type="text" class="form-control" name="C" placeholder="CNIC" required autofocus><br>
                <input type="text" class="form-control" name="ps" placeholder="Password" required><br>
                <button class="btn btn-lg btn-primary btn-block" name="sb" type="submit">
                    Sign in</button>
                <label class="checkbox pull-left">
                    <input type="checkbox" value="remember-me">
                    Remember me
                </label>
                <a href="#" class="pull-right need-help">Need help? </a><span class="clearfix"></span>
                </form>
            </div>
            
        </div>
    </div>
</div>
<?php
if(isset($_POST['sb'])){

    $CNIC=$_POST['C'];
    $password=$_POST['ps'];
   
 $query="select * from doctor where Doc_CNIC='$CNIC' AND Password='$password'";
 $run=mysqli_query($con,$query);

 $rowcount=mysqli_num_rows($run);


if($rowcount==1)
{
 session_start();
 $_SESSION['login_Doctor']= $CNIC;
    header("location:doc.php?DCNIC=$CNIC");

  }
  else{

    echo"<script>alert('CNIC or Password is invalid')</script>";
  }
  }



?>
    
</body>
</html>


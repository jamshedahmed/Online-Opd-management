<?php
session_start();
ob_start();
if(!isset($_SESSION['login_Doctor']))
{
  echo"<script>alert('You Are not login')</script>";
  header("location:/OPDPLUS/Doctor/index.php");
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>
		Admin Panel
	</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body style="background-image: url('../form/images/admin.jpg');background-size: 100%";>
<header class="header">
  <div class="container">
    <nav class="navbar navbar-inverse" role="navigation">
      <div class="navbar-header">
        <button type="button" id="nav-toggle" class="navbar-toggle" data-toggle="collapse" data-target="#main-nav"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
        <a href="#" class="navbar-brand scroll-top logo  animated bounceInLeft"><b style="font-size: 32px">OPD<i>PLUS</i></b></a> </div>
      <!--/.navbar-header-->
      <div id="main-nav" class="collapse navbar-collapse">
        <ul class="nav navbar-nav" id="mainNav">
       <?php
       $DCNIC=$_GET['DCNIC'];
       echo"
          <li><a href='http:/OPDPLUS/Doctor/Traking_time.php?DCNIC=$DCNIC' class='scroll-link'>Traking</a></li>";
          ?>
        <li><a href="My_Patients.php?cn=<?php echo $DCNIC; ?>" class="scroll-link"> My Patients </a>
          <li><a href="http:/OPDPLUS/Doctor/index.php" class="scroll-link">Log out</a></li>
         
          
          
        </ul>
      </div>
      <!--/.navbar-collapse--> 
    </nav>
    <!--/.navbar--> 
  </div>
  <!--/.container--> 
</header>



</style>
</body>
</html>
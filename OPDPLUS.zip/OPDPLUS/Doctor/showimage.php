<?php
include 'db.php';
?>

<!DOCTYPE html>
<html>
<head>
	<title>Patient Prescription Images</title>
</head>
<body style="background:url('../form/images/h5.jpg');background-size:100%;">


<?php

include 'header.php';

?>

<?php



$id=$_GET['id'];


$sql="select * from priscription where Appointment_id=$id";

$sth = $con->query($sql);
$result=mysqli_fetch_array($sth);

echo '<img style="margin-left:10%" src="data:image/jpeg;base64,'.base64_encode( $result['Priscription_Image'] ).'"/>';

?>

</body>
</html>

